#ifndef _INC_INTRO
#define _INC_INTRO


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<conio.h>
#include<windows.h>
#include<time.h>
#include<fcntl.h>
#include<unistd.h>
#include<process.h>
#include<stdbool.h>

void gotoxy(int x, int y)
{
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void Intro(){


gotoxy(18,9);
printf("INGENIOUS AUTOMATED QUESTION PAPER GENERATOR");
gotoxy(25,19);
 printf("PRESS ANY KEY TO CONTINUE ...");
 getch();
}

#endif
