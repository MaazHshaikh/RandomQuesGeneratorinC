#include"INTRO.h"


typedef struct 
	{
 		char word[500];
 	}ques;
ques quiz[200];
int counter,marks;

void Log_In();
void animation1();
void animation2();
void welcome();
int arrayQuestions(ques array[]);
int stringQuestions(ques string[]);
int pointersQuestions(ques pointers[]);
int previewPaper( ques preview[]);


int main()
	{
		Intro();
		Log_In();
	}
void animation1()
{
	int r,q;
	gotoxy(30,18);
	
	printf("Logging In...");
	
	gotoxy(30,20);
	for(r=1;r<=10;r++)
	{
		for (q=0 ; q<=1; q++)
		{
			printf("%c",219);
			usleep(95000);
		}
	}
	
}

void animation2()
{
	int r,q;
	gotoxy(30,18);
	
	printf("Loading...");
	
	gotoxy(30,20);
	for(r=1;r<=10;r++)
	{
		for (q=0 ; q<=1; q++)
		{
			printf("%c",219);
			usleep(95000);
		}
	}
	
}

void welcome()
{
		system("cls");
		int choice;		
	
	while(1)
	{
		printf("Choose the desired topic to extract questions from:");
		printf("\nPress 1 --- Arrays\nPress 2 --- Strings\nPress 3 --- Pointers\nPress 4 --- Preview Paper\nPress 5 --- Exit");
		printf("\n\nENTER YOUR CHOICE = ");
		scanf("%d", &choice);
		
		
			if(choice == 1)
				{
					system("CLS");
				
					counter = arrayQuestions(quiz); //saaray functions mein questions ka structure pass karwana hai!!!
					welcome();
					break;
				}
			else if(choice == 2)
				{
					system("CLS");
			
					counter = stringQuestions(quiz);
					welcome();
					break;
				}
			else if(choice == 3)
				{
					system("CLS");
				
					counter = pointersQuestions(quiz);
					welcome();
					break;
				}
			else if(choice == 4)
				{
					system("CLS");
					counter = previewPaper(quiz);
					welcome();
					break;
				}
			else if(choice == 5)
				{
					system("CLS");
					animation2();
					system("CLS");
					printf("\t\tCredits\n");
					printf("\t\t--------\n\n");
					printf("Instructors:\t");
					printf("ATIYA JOKHIO\t\tIRFAN AYUB\n\n");
					printf("Made By:\n");
					printf("\tUMER FARROQ (LEADER) (20K-1625)\n");
					printf("\tMAAZ HAIDER (20K-1727)\n");
					printf("\tSHOAIB SOHOO(20K-0229)\n\n");
					printf("Course Name:");
					printf("\tProgramming Fundamentals\n\n");
					printf("Section:\t");
					printf("B\n\n\n");
					printf("\t\tThe End");
					getch();
					system("taskkill/IM ConsolePauser.exe");
				}
			else
				{
					system("CLS");
					printf("\nInvalid selection! Please re-enter a valid choice.\n\n");				
				}	
		}
		
		
	}



void Log_In()
{
	system("cls");
	int i;
	char pass[100]={0};
	char user[100]={0};
	char USER[] = "FAST";
	char PASSWORD[] = "1234";
	char temp1,temp2;
	printf("Enter Username:\n");
	
	for( i=0; i<10; i++)
	{
		temp1 = getch();
		if(temp1 == 13) // ascii enter key
		{
			break;
		}
		else
		{
			user[i] = temp1;
			
		}
		printf("%c",user[i]);
	}
	printf("\nEnter Password: \n");
	for( i=0; i<10; i++)
	{
		temp2 = getch(); 
		if(temp2 == 13)
		{
			break;
		}
		else
		{
			pass[i] = temp2;
		}
		printf("*");
	}
	
	if( strcmp(pass,PASSWORD ) == 0 && strcmp(user,USER) == 0)
	{
		animation1();
		printf("\nSUCCESFULLY LOGIN\n");
		system("cls");
		welcome();
	}
	else
	{
		system("cls");
		
		printf("\nWRONG PASSWORD,TRY AGAIN \n");
		Log_In();
	}
	

}

int previewPaper( ques preview[]){
 	
 		int i,j,time;
 		printf("Enter Total Time For Exam: ");
		scanf("%d",&time);
 		system("CLS");
 	printf("NAME_______________\n\n");
	printf("ROLL#no______________\n\n");
	printf("Section______________\n\n");
	printf("Time: ");
	printf("%d\n\n",time);
	printf("Marks: ");
	printf("%d\n\n",marks);
	printf("\n\n");
	
	for(i=0;i<counter;i++){
		printf("Q%d:) ",i+1);
	
		puts(preview[i].word);
		
	}
	getch();
	system("CLS");
 	
 	
 }

int arrayQuestions(ques array[])
{
	int l, k, i, num2 ,store,temp,choice; // change
 	
	int	 arr[]={1,2,3,4,5}; //change the array name not value
 	
 	FILE *fp1,*fp2,*fp3;   //change
 	fp1=fopen("array_easy.txt","r");
	fp2=fopen("array_normal.txt","r");
	fp3=fopen("array_hard.txt","r");
	
	
		srand(time(0));
		for(i=0;i<5;i++)
		{
		store=rand()%(4);//3
		temp=arr[i];//1
		arr[i]=arr[store];//{4,3,5,2,1}
		arr[store]=temp; //{1}
		
		}
		
		
		printf("Choose the difficulty:\n1)EASY.\n2)MEDIUM.\n3)HARD.\nENTER YOUR CHOICE = ");
		scanf("%d",&choice);
		
		switch (choice)
		{
			
		case 1:{
			
			printf("\nEnter how many Questions you want. (limit 5 questions)\t");
	
				while(1)
				{
					scanf("%d",&num2);
					if(num2>0 && num2<=5)
					{
						break;
					}
					printf("Enter a suitable value please...\n");
				}
			i=counter;//0 initially
			for(k=0;k<num2;k++)
			{
			
	
					if(fp1==NULL)
			    	{
			      	  printf("File not found");        
			        
			       	  exit(1);
			  		}		
			 		else
					{  
					
						for( l=1 ; l<=arr[k] ; l++)//
						{
							
							fgets(array[i].word,500,fp1);//array[0]
						
						} 
						
							i++;
							rewind(fp1);	
				 	
			 	
			  		}
		 
			}
				marks=marks+num2*5;
				counter+=num2;
				break;
		}
			
				
		case 2:
		{
				printf("Enter how many Questions you want.(limit 5 questions)\t");
				while(1)
				{
					scanf("%d",&num2);
					if(num2>0 && num2<=5)
					{
						break;
					}
					printf("Enter a suitable value please...\n");
				}
				i=counter;
				for(k=0;k<num2;k++)
				{
				
						if(fp2==NULL)
			    	{
			      	  printf("File not found");        
			        
			       	  exit(1);
			  		}		
			 		else
					{  
						for( l=1 ; l<=arr[k] ; l++)
						{
						
							fgets(array[i].word,500,fp2);
						
						} 
				
							i++;
							rewind(fp2);	
				 	
		 	
		  			}
		 
				}
				marks=marks+num2*10;
				counter+=num2;
				break;
			
		}	
		case 3:
		{
				printf("Enter how many Questions you want.(limit 5 questions)\t");
				while(1)
				{
					scanf("%d",&num2);
					if(num2>0 && num2<=5)
					{
						break;
					}
					printf("Enter a suitable value please...\n");
				}
				i=counter;
				for(k=0;k<num2;k++)
				{
				
		
					if(fp3==NULL)
		    		{
			      	  printf("File not found");        
			        
			       	  exit(1);
		  			}		
			 		else
					{  
				
						for( l=1 ; l<=arr[k] ; l++)
						{
						
							fgets(array[i].word,500,fp3);
						
						} 
					
							i++;
							rewind(fp3);	
				 	
				 	
			  		}
		 
				}
				marks=marks+num2*15;
				counter+=num2;
					break;
			}
			
				
			
	
				
		}
		
		return counter; //figure out how to display marks at the end of paper total markssss (only marks counter maine karadia hai lallo).
}
int stringQuestions(ques string[])
{
	int l, k, i, num2 ,store1,temp1,choice1;
	int	 str[]={1,2,3,4,5}; //change the array name not value
	
	FILE *fs1,*fs2,*fs3;   //change
 	fs1=fopen("string_easy.txt","r");
	fs2=fopen("string_normal.txt","r");
	fs3=fopen("string_hard.txt","r");
	
	srand(time(0));
		for(i=0;i<5;i++)
		{
			store1=rand()%(4);
			temp1=str[i];
			str[i]=str[store1];
			str[store1]=temp1; 
		}
		
		printf("Choose the difficulty:\n1)EASY.\n2)MEDIUM.\n3)HARD.\nENTER YOUR CHOICE = ");
		scanf("%d",&choice1);
		
		switch (choice1)
		{
			case 1:
				{	
					printf("\nEnter how many Questions you want.(limit 5 questions)\t");
				while(1)
				{
					scanf("%d",&num2);
					if(num2>0 && num2<=5)
					{
						break;
					}
					printf("Enter a suitable value please...\n");
				}
					i=counter;//0 initially
					
					for(k=0;k<num2;k++)
					{
						if(fs1==NULL)
						{
							printf("File not found");        
        
       	 					 exit(1);
						}
						else
						{
							for( l=1 ; l<=str[k] ; l++)
							{
								fgets(string[i].word,500,fs1);//array[0]	
							}
							
							i++;
							rewind(fs1);
						}
					}
					marks=marks+num2*5;
					counter+=num2;
					break;
				}
		
			case 2:
					{	
						printf("\nEnter how many Questions you want.(limit 5 questions)\t");
						while(1)
						{
							scanf("%d",&num2);
							if(num2>0 && num2<=5)
							{
								break;
							}
							printf("Enter a suitable value please...\n");
						}
						i=counter;
						
						for(k=0;k<num2;k++)
						{
							if(fs2==NULL)
							{
								printf("File not found");        
	        
	       	 					 exit(1);
							}
							else
							{
								for( l=1 ; l<=str[k] ; l++)
								{
									fgets(string[i].word,500,fs2);	
								}
								

								i++;
								rewind(fs2);
							}
						}
						marks=marks+num2*10;
						counter+=num2;
						break;
					}
			case 3:
					{	
						printf("\nEnter how many Questions you want.(limit 5 questions)\t");
					while(1)
					{
						scanf("%d",&num2);
						if(num2>0 && num2<=5)
						{
							break;
						}
						printf("Enter a suitable value please...\n");
					}
						i=counter;
						
						for(k=0;k<num2;k++)
						{
							if(fs3==NULL)
							{
								printf("File not found");        
	        
	       	 					exit(1);
							}
							else
							{
								for( l=1 ; l<=str[k] ; l++)
								{
									fgets(string[i].word,500,fs3);	
								}
								

								i++;
								rewind(fs3);
							}
						}
						marks=marks+num2*15;
						counter+=num2;
						break;
					}
				}
	return counter;
}
	
int pointersQuestions(ques pointers[])
{
	int l, k, i, num2 ,store2,temp2,choice2;
	int	 ptr[]={1,2,3,4,5}; //change the array name not value
	
	FILE *fptr1,*fptr2,*fptr3;   //change
 	fptr1=fopen("string_easy.txt","r");
	fptr2=fopen("string_normal.txt","r");
	fptr3=fopen("string_hard.txt","r");
	
	srand(time(0));
		for(i=0;i<5;i++)
		{
			store2=rand()%(4);
			temp2=ptr[i];
			ptr[i]=ptr[store2];
			ptr[store2]=temp2; 
		}
		
		printf("Choose the difficulty:\n1)EASY.\n2)MEDIUM.\n3)HARD.\nENTER YOUR CHOICE = ");
		scanf("%d",&choice2);
		
		switch (choice2)
		{
			case 1:
				{	
					printf("\nEnter how many Questions you want.(limit 5 questions)\t");
				while(1)
				{
					scanf("%d",&num2);
					if(num2>0 && num2<=5)
					{
						break;
					}
					printf("Enter a suitable value please...\n");
				}
					i=counter;//0 initially
					
					for(k=0;k<num2;k++)
					{
						if(fptr1==NULL)
						{
							printf("File not found");        
        
       	 					 exit(1);
						}
						else
						{
							for( l=1 ; l<=ptr[k] ; l++)
							{
								fgets(pointers[i].word,500,fptr1);//array[0]	
							}
							
							i++;
							rewind(fptr1);
						}
					}
					marks=marks+num2*5;
					counter+=num2;
					break;
				}
		
			case 2:
					{	
						printf("\nEnter how many Questions you want.(limit 5 questions)\t");
						while(1)
					{
						scanf("%d",&num2);
						if(num2>0 && num2<=5)
						{
							break;
						}
						printf("Enter a suitable value please...\n");
					}
						i=counter;
						
						for(k=0;k<num2;k++)
						{
							if(fptr2==NULL)
							{
								printf("File not found");        
	        
	       	 					 exit(1);
							}
							else
							{
								for( l=1 ; l<=ptr[k] ; l++)
								{
									fgets(pointers[i].word,500,fptr2);	
								}
								

								i++;
								rewind(fptr2);
							}
						}
						marks=marks+num2*10;
						counter+=num2;
						break;
					}
			case 3:
					{	
						printf("\nEnter how many Questions you want.(limit 5 questions)\t");
						while(1)
					{
						scanf("%d",&num2);
						if(num2>0 && num2<=5)
						{
							break;
						}
						printf("Enter a suitable value please...\n");
					}
						i=counter;
						
						for(k=0;k<num2;k++)
						{
							if(fptr3==NULL)
							{
								printf("File not found");        
	        
	       	 					 exit(1);
							}
							else
							{
								for( l=1 ; l<=ptr[k] ; l++)
								{
									fgets(pointers[i].word,500,fptr3);	
								}
								

								i++;
								rewind(fptr3);
							}
						}
						marks=marks+num2*15;
						counter+=num2;
						break;
					}
				}
	return counter;
}
